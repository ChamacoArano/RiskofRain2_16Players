1. Copy the contents from "Modloader" into ROR2's game directory
2. Right click on "ror2-modloader-manager.exe", select run as administrator
3. Copy the contents from "MultiplayerMod" into ROR2's game directory
4. Launch the game, select multiplayer. You should now see 16 slots available.